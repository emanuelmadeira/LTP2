﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
string nome = "Emanuel ";
Console.WriteLine("Seja bem vindo(a) " + nome);
string cidade = "Pinheiral";
Console.WriteLine($"Eu gosto de {cidade}");

int idade = 16;
Console.WriteLine("Idade: " + idade);

byte valor = 255;
valor += 1;//valor = valor + 1 ;
Console.WriteLine("Valor :" + valor);



float altura = 1.76f, peso = 83.2f;
double nanoAltura = altura * 0.0000000001;
Console.WriteLine($"Sua altura é {altura}");
Console.WriteLine($"Se vc pudesse ser o homem formiga , teria altura de : {nanoAltura}nm");
Console.WriteLine($"O peso informado foi :{peso}kg");


int val1 = 32, result = 0;

result = 10 + val1++; Console.WriteLine(result); // 42
result = 10 + ++val1; Console.WriteLine(result); // 44

string tuin = "10";
string tuin2 = "20";
Console.WriteLine(tuin+tuin2);






